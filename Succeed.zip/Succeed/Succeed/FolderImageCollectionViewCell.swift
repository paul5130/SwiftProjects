//
//  FolderImageCollectionViewCell.swift
//  Succeed
//
//  Created by Paul Wen on 2017/3/18.
//  Copyright © 2017年 Paul Wen. All rights reserved.
//

import UIKit

class FolderImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageCell: UIImageView!
}
