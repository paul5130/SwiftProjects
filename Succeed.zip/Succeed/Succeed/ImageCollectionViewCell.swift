//
//  ImageCollectionViewCell.swift
//  Succeed
//
//  Created by Paul Wen on 2017/2/2.
//  Copyright © 2017年 Paul Wen. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
