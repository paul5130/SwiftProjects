
import UIKit

class SettingController: TitleViewController {

    @IBOutlet weak var testImage: ImageViewWithGradient!
    override func viewDidLoad() {
        super.viewDidLoad()
//        testImage.setup(gradientColor: UIColor.init(red: 100/255, green: 139/255, blue: 211/255, alpha: 1))
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

